package com.sky.test;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class HttpClientTest {

    public void httptest() throws Exception{
        CloseableHttpClient httpClient = HttpClients.createDefault();

        HttpGet httpGet = new HttpGet("http//localhost:8080/user/shop/status");

        CloseableHttpResponse execute = httpClient.execute(httpGet);

        int statusCode = execute.getStatusLine().getStatusCode();

        System.out.println("服务器返回的状态码为"+statusCode);

        HttpEntity entity = execute.getEntity();
        String s = EntityUtils.toString(entity);
        System.out.println("服务端返回的数据为"+s);

        execute.close();
        httpClient.close();


    }
}
