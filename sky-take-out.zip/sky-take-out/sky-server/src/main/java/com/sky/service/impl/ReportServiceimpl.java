package com.sky.service.impl;

import com.sky.dto.GoodsSalesDTO;
import com.sky.entity.Orders;
import com.sky.mapper.OrderMapper;
import com.sky.mapper.ReportMapper;
import com.sky.mapper.UserMapper;
import com.sky.service.ReportService;
import com.sky.vo.OrderReportVO;
import com.sky.vo.SalesTop10ReportVO;
import com.sky.vo.TurnoverReportVO;
import com.sky.vo.UserReportVO;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.SortParameters;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ReportServiceimpl implements ReportService {

    @Autowired
    private ReportMapper reportMapper;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private UserMapper userMapper;
    public TurnoverReportVO getTurnoverStatistics(LocalDate begin, LocalDate end){
        //存放begin和end 每天的日期
        List<LocalDate> listdate = new ArrayList<>();


        listdate.add(begin);


        while (!begin.equals(end)){
            //日期的计算，计算指定日期的后一天对应的日期
           begin = begin.plusDays(1);
           listdate.add(begin);
        }

        //存放每天营业额
        List<Double> turnoverList = new ArrayList<>();
        for (LocalDate date : listdate) {
            //查询date日期对应的营业额数据，数据是指已完成的
            LocalDateTime beginTime = LocalDateTime.of(date, LocalTime.MIN);
            LocalDateTime endTime = LocalDateTime.of(date, LocalTime.MAX);

            Map map = new HashMap<>();
            map.put("begin",beginTime);
            map.put("end",endTime);
            map.put("Status", Orders.COMPLETED);
         Double turnover = orderMapper.sumByMap(map);
         turnover = turnover == null ? 0.0 : turnover;
         turnoverList.add(turnover);

        }
        //封装返回结果
        return TurnoverReportVO
                .builder()
                .dateList(StringUtils.join(listdate,","))
                .turnoverList(StringUtils.join(turnoverList,","))
                .build();
    }

    @Override
    public UserReportVO getuserStatistics(LocalDate begin, LocalDate end) {

        List<LocalDate> listdate = new ArrayList<>();

        listdate.add(begin);

        while (!begin.equals(end)){
            //日期的计算，计算指定日期的后一天对应的日期
            begin = begin.plusDays(1);
            listdate.add(begin);
        }

        //存放每天新增的用户数量
        List<Integer> userList = new ArrayList<>();
        List<Integer> TotaluserList = new ArrayList<>();

        for (LocalDate date : listdate) {
            //查询date日期对应的营业额数据，数据是指已完成的
            LocalDateTime beginTime = LocalDateTime.of(date, LocalTime.MIN);
            LocalDateTime endTime = LocalDateTime.of(date, LocalTime.MAX);

            Map map = new HashMap<>();
            map.put("end",endTime);

            //总用户数量
            Integer TotalUser = userMapper.countByMap(map);

            map.put("begin",beginTime);

            Integer newUser = userMapper.countByMap(map);

            userList.add(newUser);
            TotaluserList.add(TotalUser);
        }
        //userMapper.countByMap(userList,TotaluserList);

        return UserReportVO.builder()
                .dateList(StringUtils.join(listdate,","))
                .totalUserList(StringUtils.join(TotaluserList,","))
                .newUserList(StringUtils.join(userList,","))
                .build();
    }

    @Override
    public OrderReportVO getordersStatistics(LocalDate begin, LocalDate end) {

        List<LocalDate> listdate = new ArrayList<>();

        listdate.add(begin);

        while (!begin.equals(end)){
            //日期的计算，计算指定日期的后一天对应的日期
            begin = begin.plusDays(1);
            listdate.add(begin);
        }

        List<Integer> ordercountList = new ArrayList<>();   //每日订单数

        List<Integer> validOrderCountList = new ArrayList<>();//每日有效订单数

        for (LocalDate date : listdate) {

            LocalDateTime beginTime = LocalDateTime.of(date, LocalTime.MIN);

            LocalDateTime endTime = LocalDateTime.of(date, LocalTime.MAX);

            Integer orderCount = getOrderCount(beginTime, endTime, null);

            Integer validorderCount = getOrderCount(beginTime, endTime, Orders.COMPLETED);

            ordercountList.add(orderCount);

            validOrderCountList.add(validorderCount);

        }

        Integer totalOrderCount = ordercountList.stream().reduce(Integer::sum).get();

        Integer validOrderCount = validOrderCountList.stream().reduce(Integer::sum).get();

        Double orderCompletionRate = 0.0;
        if (validOrderCount != null) {
            orderCompletionRate = totalOrderCount.doubleValue() / validOrderCount;
        }



        return OrderReportVO.builder()
                .dateList(StringUtils.join(listdate,","))
                .orderCountList(StringUtils.join(ordercountList,","))
                .validOrderCountList(StringUtils.join(validOrderCountList,","))
                .totalOrderCount(totalOrderCount)
                .validOrderCount(validOrderCount)
                .orderCompletionRate(orderCompletionRate)
                .build();
    }

    @Override
    public SalesTop10ReportVO getSalesTop10(LocalDate begin, LocalDate end) {

        LocalDateTime beginTime = LocalDateTime.of(begin, LocalTime.MIN);
        LocalDateTime endTime = LocalDateTime.of(end, LocalTime.MAX);

        List<GoodsSalesDTO> goodsSalesDTOS = orderMapper.getsalesTop(beginTime, endTime);

        List<String> names = goodsSalesDTOS.stream().map(GoodsSalesDTO::getName).collect(Collectors.toList());

        String nameList = StringUtils.join(names, ",");

        List<Integer> number = goodsSalesDTOS.stream().map(GoodsSalesDTO::getNumber).collect(Collectors.toList());

        String numberList = StringUtils.join(number, ",");

        return SalesTop10ReportVO.builder()
                .nameList(nameList)
                .numberList(numberList)
                .build();
    }

    private Integer getOrderCount(LocalDateTime begin , LocalDateTime end , Integer status){

        Map map = new HashMap<>();
        map.put("begin",begin);
        map.put("end",end);
        map.put("Status", status);

        return orderMapper.CountBymap(map);
    }
}
