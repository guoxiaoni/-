package com.sky.mapper;

import com.github.pagehelper.Page;
import com.sky.annotation.AutoFill;
import com.sky.dto.EmployeePageQueryDTO;
import com.sky.entity.Employee;
import com.sky.enumeration.OperationType;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface EmployeeMapper {

    /**
     * 根据用户名查询员工
     * @param username
     * @return
     */
    @Select("select * from employee where username = #{username}")
    Employee getByUsername(String username);

    @Insert("insert into employee (name, username, password, phone, sex, id_number, create_time, update_time, create_user, update_user) " +
            "VALUES "+"(#{name},#{username},#{password},#{phone},#{sex},#{idNumber},#{createTime},#{updateTime},#{createUser},#{updateUser})")

    /**
     * 利用aop事物管理，将公共字段实现自动处理
     */
    @AutoFill(value = OperationType.INSERT)//表示这是插入


    void insert(Employee employee);

    //分页查找
    Page<Employee> pageQuery(EmployeePageQueryDTO employeePageQueryDTO);


    //员工的禁用和启用
    //员工的修改
    @AutoFill(value = OperationType.UPDATE)
    void update(Employee employee);


    //根据Id查找员工
    @Select("select *from sky_take_out.employee where id = #{id}")
    Employee getbyID(Long id);

    @Select("select * from sky_take_out.employee where password = #{password}")
    Employee getPassword(String password);
}
