package com.sky.service.impl;

import com.sky.context.BaseContext;
import com.sky.dto.ShoppingCartDTO;
import com.sky.entity.Dish;
import com.sky.entity.Setmeal;
import com.sky.entity.ShoppingCart;
import com.sky.mapper.DishMapper;
import com.sky.mapper.SetmealMapper;
import com.sky.mapper.ShoppingCartMapper;
import com.sky.result.Result;
import com.sky.service.ShoppingCartService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class ShoppingCartServiceImpl implements ShoppingCartService {

    @Autowired
    private ShoppingCartMapper shoppingCartMapper;
    @Autowired
    private DishMapper dishMapper;
    @Autowired
    private SetmealMapper setmealMapper;

    @Override
    public void addShooping(ShoppingCartDTO shoppingCartDTO) {


        //判断当前加入购物车的东西是否存在
        ShoppingCart shoopingCart = new ShoppingCart();
        BeanUtils.copyProperties(shoppingCartDTO,shoopingCart);
        Long userId = BaseContext.getCurrentId();
        shoopingCart.setUserId(userId);

        List<ShoppingCart> list = shoppingCartMapper.list(shoopingCart);

        //如果已经存在，则数量要＋1

        if (list != null && list.size()>0){
            ShoppingCart cart = list.get(0);
            cart.setNumber(cart.getNumber() + 1);
            shoppingCartMapper.updateById(cart);
        }else {
            //如果不存在，则需要插入一条数据

            Long dishId = shoppingCartDTO.getDishId();
            if (dishId != null){
                Dish byId = dishMapper.getById(dishId);
                shoopingCart.setName(byId.getName());
                shoopingCart.setImage(byId.getImage());
                shoopingCart.setAmount(byId.getPrice());
            }else {

                Long setmealId = shoppingCartDTO.getSetmealId();
                Setmeal setmealbyId = setmealMapper.getById(setmealId);
                shoopingCart.setName(setmealbyId.getName());
                shoopingCart.setImage(setmealbyId.getImage());
                shoopingCart.setAmount(setmealbyId.getPrice());

            }
            shoopingCart.setNumber(1);
            shoopingCart.setCreateTime(LocalDateTime.now());
            shoppingCartMapper.insert(shoopingCart);

        }


    }

    @Override
    public List<ShoppingCart> showShoppingCart() {
        Long userId = BaseContext.getCurrentId();
        ShoppingCart shoppingCart =ShoppingCart.builder()
                .userId(userId)
                .build();
        List<ShoppingCart> list = shoppingCartMapper.list(shoppingCart);
        return list;
    }

    @Override
    public void deletShoppingCart() {
        Long userid = BaseContext.getCurrentId();
        shoppingCartMapper.delete(userid);
    }


}
