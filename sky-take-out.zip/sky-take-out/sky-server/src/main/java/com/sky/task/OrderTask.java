package com.sky.task;

import com.sky.entity.Orders;
import com.sky.mapper.OrderMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

@Component
@Slf4j
public class OrderTask {

    @Autowired
    private OrderMapper orderMapper;
    @Scheduled(cron = "0 0 1 * * ?")
    public void dingdan(){
        log.info("订单超时查询: {}", LocalDateTime.now());

        LocalDateTime now = LocalDateTime.now().plusMinutes(-15);

        List<Orders> ordersList = orderMapper.getDingdan(Orders.PENDING_PAYMENT, now);

        if (ordersList != null && ordersList.size()!=0){
            for (Orders orders : ordersList) {
                    orders.setStatus(Orders.CANCELLED);
                    orders.setCancelReason("订单超时");
                    orders.setCancelTime(LocalDateTime.now());
                    orderMapper.update(orders);
            }

        }


    }

    @Scheduled(cron = "0 0 1 * * ?")
    ///@Scheduled(cron = "1/5 * * * * ?")
    public void Pdingdan(){

        log.info("订单派送超时查询: {}", LocalDateTime.now());

        LocalDateTime now = LocalDateTime.now().plusMinutes(-60);

        List<Orders> ordersList = orderMapper.getDingdan(Orders.DELIVERY_IN_PROGRESS, now);

        if (ordersList != null && ordersList.size()!=0){
            for (Orders orders : ordersList) {
                orders.setStatus(Orders.CANCELLED);
                orderMapper.update(orders);
            }

        }

    }
}
